package mvc_Olympice_listener;

public interface OlympiceBLEventsListener {
	public void addCountryToView(String country);
	
	//*
	public void addAddRefereeToView(String name);
	
	//*
	public void addStadiumToView(String nameStadium);
	
	public void addCompetitorToView(String competitor);
	
	public void addWinnersOfTheCompetitionToView(String firstPlaceInTheOlympics, String secondPlaceInTheOlympics,
			String thirdPlaceInTheOlympics);
	
}
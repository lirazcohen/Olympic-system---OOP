package mvc_Olympics_model;

public class Stadium {
	private int numberOfSeats;
	private String nameStadium;
	private String location;
	
	public Stadium(int numberOfSeats, String nameStadium, String location) {
		super();
		this.numberOfSeats = numberOfSeats;
		this.nameStadium = nameStadium;
		this.location = location;
	}
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	public String getNameStadium() {
		return nameStadium;
	}
	public String getLocation() {
		return location;
	}
	
	
	
}

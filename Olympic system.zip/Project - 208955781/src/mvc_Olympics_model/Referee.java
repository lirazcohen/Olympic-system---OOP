package mvc_Olympics_model;

public class Referee {

	private String name;
	private String Country;
	private CompetitionDomains domain;
	
	public Referee(String name, String country, CompetitionDomains domain) {
		super();
		this.name = name;
		Country = country;
		this.domain = domain;
	}

	public String getName() {
		return name;
	}

	public String getCountry() {
		return Country;
	}

	public CompetitionDomains getDomain() {
		return domain;
	}
	
}

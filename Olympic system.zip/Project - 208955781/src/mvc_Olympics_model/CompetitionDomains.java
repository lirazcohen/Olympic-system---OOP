package mvc_Olympics_model;

public enum CompetitionDomains {
	RUNNER, HIGH_JUMP
}

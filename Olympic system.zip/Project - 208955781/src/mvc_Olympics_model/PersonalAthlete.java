package mvc_Olympics_model;

import java.util.Vector;

public class PersonalAthlete extends Sportsman implements Comparable <PersonalAthlete>{
	private int achievements;
	
	public PersonalAthlete(String name, String country, Vector<CompetitionDomains> typeDomain) {
		super(name, country, typeDomain, CompetitionType.SINGLE);
		this.achievements = 0;
	}

	public int getAchievements() {
		return achievements;
	}
		
	public void addAchievements(int achievements) {
		this.achievements += achievements;
	}

	public int compareTo(PersonalAthlete other) {
        return Integer.compare(this.getAchievements(),other.getAchievements());
	}

}

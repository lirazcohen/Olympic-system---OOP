package mvc_Olympics_model;

import java.util.Vector;

public abstract class Sportsman implements Competitors {
	
	private String name;
	private String country;
	private Vector<CompetitionDomains> typeDomains;
	private CompetitionType type;
	
	public Sportsman(String name, String country, Vector<CompetitionDomains> typeDomain, CompetitionType type) {
		super();
		this.name = name;
		this.country = country;
		this.typeDomains = typeDomain;
		this.type = type;
	}
	
	@Override
	public Vector<CompetitionDomains> getTypeDomain() {
		return this.typeDomains;
	}
	
	
	@Override
	public CompetitionType getCompetitionEligible() {
		return this.type;
	}

	public void addTypeDomain(CompetitionDomains typeDomain) {
		if (!this.typeDomains.contains(typeDomain))
			this.typeDomains.add(typeDomain);
	}
	public String getName() {
		return name;
	}
	public String getCountry() {
		return country;
	}
	
	
}

package mvc_Olympics_model;

public enum CompetitionType {
	SINGLE, TEAM
}

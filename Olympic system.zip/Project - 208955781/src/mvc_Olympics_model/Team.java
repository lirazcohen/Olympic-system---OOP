package mvc_Olympics_model;

import java.util.ArrayList;
import java.util.Vector;


public class Team implements Comparable<Team>, Competitors {

	private int achievements;
	private ArrayList<Sportsman> athletes;
	private CompetitionDomains typeDomain;
	private CompetitionType type;
	private String country;
	
	public Team(String country, CompetitionDomains domain) {
		super();
		this.country = country;
		this.typeDomain = domain;
		this.athletes = new ArrayList<Sportsman>();
		this.achievements = 0;
		this.type = CompetitionType.TEAM;
	}

	public int getAchievements() {
		return achievements;
	}

	@Override
	public Vector<CompetitionDomains> getTypeDomain() {
		Vector<CompetitionDomains> domains = new Vector<CompetitionDomains>();
		domains.add(this.typeDomain);
		return domains;
	}

	@Override
	public CompetitionType getCompetitionEligible() {
		return this.type;
	}

	public void addAchievements(int achievements) {
		this.achievements += achievements;
	}

	public ArrayList<Sportsman> getAthletes() {
		return athletes;
	}

	public void addAthlete(Sportsman athlete) {
		if (!this.athletes.contains(athlete) && athlete.getTypeDomain().contains(this.typeDomain))
			this.athletes.add(athlete);
	}

	public String getCountry() {
		return country;
	}

	@Override
	public int compareTo(Team other) {
		return Integer.compare(this.getAchievements(), other.getAchievements());
	}

	
}
